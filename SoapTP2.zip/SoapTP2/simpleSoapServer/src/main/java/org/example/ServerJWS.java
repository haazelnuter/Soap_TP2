package org.example;
import jakarta.xml.ws.Endpoint;
import org.example.WS.BanqueService;

import static com.sun.tools.rngom.parse.compact.CompactSyntaxConstants.WS;

public class ServerJWS {
    public static void main(String[] args) {
        //connecteur pour le web service
        //ni accessivble que pour local
        //MAINTENANT ON A FAIT webservice , 2 server JWS
        Endpoint.publish("http://0.0.0.0:9191/",new BanqueService());
        System.out.println("Web service deploye sur l'adresse: http://localhost:9191/ ");

    }
}

