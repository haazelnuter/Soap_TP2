import proxy.BanqueService;
import proxy.BanqueWS;
import proxy.Compte;

public class ClientWS {
    public static void main(String[] args) {
        //sub= midlleware
        //banqueWS= server
        BanqueService sub =new BanqueWS().getBanqueServicePort();
        System.out.println(sub.convert(2300));
        Compte cp= sub.getCompte(8);
        System.out.println(cp.getCode());
        System.out.println(cp.getSolde());

    }
}
